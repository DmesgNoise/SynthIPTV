#ifndef FFTOOLS_FFMPEG_PLUTOPAIR_H
#define FFTOOLS_FFMPEG_PLUTOPAIR_H

int plutofix_paired_mode_requested(void);
int plutofix_run_paired_mux(void);

#endif
