#include "config.h"

#include <errno.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "libavutil/avstring.h"
#include "libavutil/dict.h"
#include "libavutil/error.h"
#include "libavutil/log.h"
#include "libavutil/mathematics.h"
#include "libavutil/mem.h"
#include "libavutil/opt.h"
#include "libavutil/time.h"
#include "libavformat/avformat.h"

#include "ffmpeg_plutopair.h"

#define PF_QUEUE_MAX 128

typedef struct PacketNode {
    AVPacket *pkt;
    struct PacketNode *next;
} PacketNode;

typedef struct PairedInput {
    int fd;
    enum AVMediaType type;
    const char *label;

    AVFormatContext *fmt;
    int stream_index;
    int ready;
    int error;
    int eof;
    int abort;

    PacketNode *head;
    PacketNode *tail;
    int queue_len;

    pthread_mutex_t lock;
    pthread_cond_t cond;
    pthread_t thread;
} PairedInput;

static int env_fd(const char *name)
{
    const char *value = getenv(name);
    char *end = NULL;
    long fd;

    if (!value || !*value)
        return -1;
    errno = 0;
    fd = strtol(value, &end, 10);
    if (errno || !end || *end || fd < 0 || fd > INT32_MAX)
        return -1;
    return (int)fd;
}

int plutofix_paired_mode_requested(void)
{
    const char *value = getenv("PLUTOFIX_PAIRED_MODE");
    return value && !strcmp(value, "1");
}

static void paired_signal(PairedInput *in)
{
    pthread_cond_broadcast(&in->cond);
}

static void paired_set_error(PairedInput *in, int err)
{
    pthread_mutex_lock(&in->lock);
    if (!in->error)
        in->error = err < 0 ? err : AVERROR(EIO);
    in->eof = 1;
    paired_signal(in);
    pthread_mutex_unlock(&in->lock);
}

static int queue_push(PairedInput *in, AVPacket *pkt)
{
    PacketNode *node = av_mallocz(sizeof(*node));
    if (!node)
        return AVERROR(ENOMEM);
    node->pkt = pkt;

    pthread_mutex_lock(&in->lock);
    while (!in->abort && in->queue_len >= PF_QUEUE_MAX)
        pthread_cond_wait(&in->cond, &in->lock);
    if (in->abort) {
        pthread_mutex_unlock(&in->lock);
        av_free(node);
        return AVERROR_EXIT;
    }
    if (in->tail)
        in->tail->next = node;
    else
        in->head = node;
    in->tail = node;
    in->queue_len++;
    paired_signal(in);
    pthread_mutex_unlock(&in->lock);
    return 0;
}

static AVPacket *queue_pop(PairedInput *in)
{
    PacketNode *node;
    AVPacket *pkt;

    pthread_mutex_lock(&in->lock);
    node = in->head;
    if (!node) {
        pthread_mutex_unlock(&in->lock);
        return NULL;
    }
    in->head = node->next;
    if (!in->head)
        in->tail = NULL;
    in->queue_len--;
    paired_signal(in);
    pthread_mutex_unlock(&in->lock);

    pkt = node->pkt;
    av_free(node);
    return pkt;
}

static AVPacket *queue_peek(PairedInput *in)
{
    AVPacket *pkt = NULL;
    pthread_mutex_lock(&in->lock);
    if (in->head)
        pkt = in->head->pkt;
    pthread_mutex_unlock(&in->lock);
    return pkt;
}

static void *paired_reader(void *opaque)
{
    PairedInput *in = opaque;
    const AVInputFormat *iformat = av_find_input_format("mpegts");
    AVDictionary *opts = NULL;
    char url[64];
    int ret;

    snprintf(url, sizeof(url), "pipe:%d", in->fd);
    av_dict_set(&opts, "probesize", "131072", 0);
    av_dict_set(&opts, "analyzeduration", "500000", 0);
    av_dict_set(&opts, "scan_all_pmts", "1", 0);

    in->fmt = avformat_alloc_context();
    if (!in->fmt) {
        paired_set_error(in, AVERROR(ENOMEM));
        av_dict_free(&opts);
        return NULL;
    }

    ret = avformat_open_input(&in->fmt, url, iformat, &opts);
    av_dict_free(&opts);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR,
               "PLUTOFIX_PAIRED %s input open failed: %s\n",
               in->label, av_err2str(ret));
        paired_set_error(in, ret);
        return NULL;
    }

    ret = avformat_find_stream_info(in->fmt, NULL);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR,
               "PLUTOFIX_PAIRED %s stream info failed: %s\n",
               in->label, av_err2str(ret));
        paired_set_error(in, ret);
        return NULL;
    }

    in->stream_index = av_find_best_stream(in->fmt, in->type, -1, -1, NULL, 0);
    if (in->stream_index < 0) {
        av_log(NULL, AV_LOG_ERROR,
               "PLUTOFIX_PAIRED %s required stream missing\n", in->label);
        paired_set_error(in, in->stream_index);
        return NULL;
    }

    pthread_mutex_lock(&in->lock);
    in->ready = 1;
    paired_signal(in);
    pthread_mutex_unlock(&in->lock);

    av_log(NULL, AV_LOG_INFO,
           "PLUTOFIX_PAIRED %s READY stream=%d time_base=%d/%d\n",
           in->label, in->stream_index,
           in->fmt->streams[in->stream_index]->time_base.num,
           in->fmt->streams[in->stream_index]->time_base.den);

    while (1) {
        AVPacket *pkt;

        pthread_mutex_lock(&in->lock);
        if (in->abort) {
            pthread_mutex_unlock(&in->lock);
            break;
        }
        pthread_mutex_unlock(&in->lock);

        pkt = av_packet_alloc();
        if (!pkt) {
            paired_set_error(in, AVERROR(ENOMEM));
            break;
        }

        ret = av_read_frame(in->fmt, pkt);
        if (ret < 0) {
            av_packet_free(&pkt);
            pthread_mutex_lock(&in->lock);
            if (ret != AVERROR_EOF && ret != AVERROR_EXIT && !in->abort)
                in->error = ret;
            in->eof = 1;
            paired_signal(in);
            pthread_mutex_unlock(&in->lock);
            break;
        }

        if (pkt->stream_index != in->stream_index) {
            av_packet_free(&pkt);
            continue;
        }

        ret = queue_push(in, pkt);
        if (ret < 0) {
            av_packet_free(&pkt);
            break;
        }
    }

    return NULL;
}

static void paired_init(PairedInput *in, int fd, enum AVMediaType type,
                        const char *label)
{
    memset(in, 0, sizeof(*in));
    in->fd = fd;
    in->type = type;
    in->label = label;
    in->stream_index = -1;
    pthread_mutex_init(&in->lock, NULL);
    pthread_cond_init(&in->cond, NULL);
}

static void paired_abort(PairedInput *in)
{
    pthread_mutex_lock(&in->lock);
    in->abort = 1;
    paired_signal(in);
    pthread_mutex_unlock(&in->lock);
}

static void paired_destroy(PairedInput *in)
{
    PacketNode *node;

    while ((node = in->head)) {
        in->head = node->next;
        av_packet_free(&node->pkt);
        av_free(node);
    }
    in->tail = NULL;

    if (in->fmt)
        avformat_close_input(&in->fmt);
    pthread_cond_destroy(&in->cond);
    pthread_mutex_destroy(&in->lock);
}

static int paired_wait_ready(PairedInput *in)
{
    int ret = 0;
    pthread_mutex_lock(&in->lock);
    while (!in->ready && !in->error && !in->eof)
        pthread_cond_wait(&in->cond, &in->lock);
    if (in->error)
        ret = in->error;
    else if (!in->ready)
        ret = AVERROR_EOF;
    pthread_mutex_unlock(&in->lock);
    return ret;
}

static int paired_state(PairedInput *in, int *eof, int *error, int *queued)
{
    pthread_mutex_lock(&in->lock);
    *eof = in->eof;
    *error = in->error;
    *queued = in->queue_len;
    pthread_mutex_unlock(&in->lock);
    return 0;
}

static int64_t packet_time(const AVPacket *pkt, AVRational tb)
{
    int64_t ts = pkt->dts != AV_NOPTS_VALUE ? pkt->dts : pkt->pts;
    if (ts == AV_NOPTS_VALUE)
        return INT64_MAX;
    return av_rescale_q(ts, tb, AV_TIME_BASE_Q);
}

static int write_native_packet(AVFormatContext *out, AVPacket *pkt,
                               AVStream *in_stream, AVStream *out_stream)
{
    pkt->stream_index = out_stream->index;
    av_packet_rescale_ts(pkt, in_stream->time_base, out_stream->time_base);
    pkt->pos = -1;
    return av_write_frame(out, pkt);
}

int plutofix_run_paired_mux(void)
{
    PairedInput video, audio;
    AVFormatContext *out = NULL;
    AVStream *vout = NULL, *aout = NULL;
    AVDictionary *muxopts = NULL;
    const char *output_url = getenv("PLUTOFIX_PAIRED_OUTPUT");
    int video_fd = env_fd("PLUTOFIX_VIDEO_FD");
    int audio_fd = env_fd("PLUTOFIX_AUDIO_FD");
    int ret = 0, v_started = 0, a_started = 0;

    if (video_fd < 0 || audio_fd < 0) {
        av_log(NULL, AV_LOG_ERROR,
               "PLUTOFIX_PAIRED invalid input fd configuration\n");
        return AVERROR(EINVAL);
    }
    if (!output_url || !*output_url)
        output_url = "pipe:1";

    paired_init(&video, video_fd, AVMEDIA_TYPE_VIDEO, "VIDEO");
    paired_init(&audio, audio_fd, AVMEDIA_TYPE_AUDIO, "AUDIO");

    av_log(NULL, AV_LOG_INFO,
           "PLUTOFIX_PAIRED START video_fd=%d audio_fd=%d native_timestamps=1\n",
           video_fd, audio_fd);

    if (pthread_create(&video.thread, NULL, paired_reader, &video)) {
        ret = AVERROR(errno ? errno : EIO);
        goto done;
    }
    v_started = 1;
    if (pthread_create(&audio.thread, NULL, paired_reader, &audio)) {
        ret = AVERROR(errno ? errno : EIO);
        goto done;
    }
    a_started = 1;

    ret = paired_wait_ready(&video);
    if (ret < 0)
        goto done;
    ret = paired_wait_ready(&audio);
    if (ret < 0)
        goto done;

    ret = avformat_alloc_output_context2(&out, NULL, "mpegts", output_url);
    if (ret < 0 || !out) {
        ret = ret < 0 ? ret : AVERROR(ENOMEM);
        goto done;
    }

    vout = avformat_new_stream(out, NULL);
    aout = avformat_new_stream(out, NULL);
    if (!vout || !aout) {
        ret = AVERROR(ENOMEM);
        goto done;
    }

    ret = avcodec_parameters_copy(vout->codecpar,
                                  video.fmt->streams[video.stream_index]->codecpar);
    if (ret < 0)
        goto done;
    ret = avcodec_parameters_copy(aout->codecpar,
                                  audio.fmt->streams[audio.stream_index]->codecpar);
    if (ret < 0)
        goto done;

    vout->codecpar->codec_tag = 0;
    aout->codecpar->codec_tag = 0;
    vout->time_base = video.fmt->streams[video.stream_index]->time_base;
    aout->time_base = audio.fmt->streams[audio.stream_index]->time_base;
    out->avoid_negative_ts = AVFMT_AVOID_NEG_TS_DISABLED;
    out->max_interleave_delta = 0;
    out->max_delay = 0;
    out->flags |= AVFMT_FLAG_FLUSH_PACKETS;

    if (!(out->oformat->flags & AVFMT_NOFILE)) {
        ret = avio_open2(&out->pb, output_url, AVIO_FLAG_WRITE, NULL, NULL);
        if (ret < 0)
            goto done;
    }

    av_dict_set(&muxopts, "mpegts_copyts", "1", 0);

    ret = avformat_write_header(out, &muxopts);
    av_dict_free(&muxopts);
    if (ret < 0)
        goto done;

    av_log(NULL, AV_LOG_INFO,
           "PLUTOFIX_PAIRED MUX READY video_tb=%d/%d audio_tb=%d/%d\n",
           video.fmt->streams[video.stream_index]->time_base.num,
           video.fmt->streams[video.stream_index]->time_base.den,
           audio.fmt->streams[audio.stream_index]->time_base.num,
           audio.fmt->streams[audio.stream_index]->time_base.den);

    while (1) {
        AVPacket *vpkt = NULL, *apkt = NULL, *pkt = NULL;
        PairedInput *src = NULL;
        AVStream *instream = NULL, *outstream = NULL;
        int veof, aeof, verr, aerr, vq, aq;

        paired_state(&video, &veof, &verr, &vq);
        paired_state(&audio, &aeof, &aerr, &aq);
        if (verr && verr != AVERROR_EOF) {
            ret = verr;
            break;
        }
        if (aerr && aerr != AVERROR_EOF) {
            ret = aerr;
            break;
        }
        if (veof && aeof && !vq && !aq)
            break;

        vpkt = queue_peek(&video);
        apkt = queue_peek(&audio);

        if (!vpkt && !veof) {
            pthread_mutex_lock(&video.lock);
            if (!video.head && !video.eof && !video.error)
                pthread_cond_wait(&video.cond, &video.lock);
            pthread_mutex_unlock(&video.lock);
            continue;
        }
        if (!apkt && !aeof) {
            pthread_mutex_lock(&audio.lock);
            if (!audio.head && !audio.eof && !audio.error)
                pthread_cond_wait(&audio.cond, &audio.lock);
            pthread_mutex_unlock(&audio.lock);
            continue;
        }

        if (vpkt && apkt) {
            int64_t vt = packet_time(vpkt,
                video.fmt->streams[video.stream_index]->time_base);
            int64_t at = packet_time(apkt,
                audio.fmt->streams[audio.stream_index]->time_base);
            src = vt <= at ? &video : &audio;
        } else if (vpkt) {
            src = &video;
        } else if (apkt) {
            src = &audio;
        } else {
            av_usleep(1000);
            continue;
        }

        if (src == &video) {
            pkt = queue_pop(&video);
            instream = video.fmt->streams[video.stream_index];
            outstream = vout;
        } else {
            pkt = queue_pop(&audio);
            instream = audio.fmt->streams[audio.stream_index];
            outstream = aout;
        }
        if (!pkt)
            continue;

        ret = write_native_packet(out, pkt, instream, outstream);
        av_packet_free(&pkt);
        if (ret < 0)
            break;
    }

    if (out && out->pb)
        avio_flush(out->pb);
    if (out && ret >= 0)
        ret = av_write_trailer(out);

    if (ret >= 0)
        av_log(NULL, AV_LOG_INFO,
               "PLUTOFIX_PAIRED EOF complete independent A/V epoch\n");

done:
    paired_abort(&video);
    paired_abort(&audio);
    if (v_started)
        pthread_join(video.thread, NULL);
    if (a_started)
        pthread_join(audio.thread, NULL);

    if (out) {
        if (!(out->oformat->flags & AVFMT_NOFILE) && out->pb)
            avio_closep(&out->pb);
        avformat_free_context(out);
    }
    av_dict_free(&muxopts);
    paired_destroy(&video);
    paired_destroy(&audio);

    if (ret < 0)
        av_log(NULL, AV_LOG_ERROR,
               "PLUTOFIX_PAIRED FAILED: %s\n", av_err2str(ret));
    return ret < 0 ? 1 : 0;
}
